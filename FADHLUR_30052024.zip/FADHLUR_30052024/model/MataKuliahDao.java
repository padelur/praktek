/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FADHLUR_30052024.model;
import FADHLUR_30052024.model.MataKuliah;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author SriWahyuni_2301091030
 */
public class MataKuliahDao {
    private List<MataKuliah> data = new ArrayList<MataKuliah>();
    
    public MataKuliahDao()
    {
        data.add(new MataKuliah("ISY3303","PBO","2","4"));
        data.add(new MataKuliah("ISY3301","Sistem Basis Data","2","5"));
        
    }
    
    public void insert(MataKuliah m)
    {
        data.add(m);
    }
    
    public void update(int index, MataKuliah m)
    {
        data.set(index, m);
    }
    
    public void delete(int index)
    {
        data.remove(index);
    }

    public MataKuliah getMataKuliah(int index)
    {
        return data.get(index);
    }

    public List<MataKuliah> getAllMataKuliah() 
    {
        return data;
    }
}
