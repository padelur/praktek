/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FADHLUR_30052024.model;

/**
 *
 * @author ACER
 */
public class MataKuliah {
    private String Kode;
    private String MK;
    private String Smt;
    private String Sks;

    public MataKuliah() {
    }

    public MataKuliah(String Kode, String Smt, String MK,  String Sks) {
        this.Kode = Kode;
        this.Smt = Smt;
        this.MK = MK;
        this.Sks = Sks;
    }

    public String getKode() {
        return Kode;
    }

    public void setKode(String Kode) {
        this.Kode = Kode;
    }

    public String getMK() {
        return MK;
    }

    public void setMK(String MK) {
        this.MK = MK;
    }

    public String getSmt() {
        return Smt;
    }

    public void setSmt(String Smt) {
        this.Smt = Smt;
    }

    public String getSks() {
        return Sks;
    }

    public void setSks(String Sks) {
        this.Sks = Sks;
    }
    
   
    
}
